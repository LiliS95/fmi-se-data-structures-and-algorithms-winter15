
public interface IFrontBookkeeper {
	String updateFront(String[] news);
}
